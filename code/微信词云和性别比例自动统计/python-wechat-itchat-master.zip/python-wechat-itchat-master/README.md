# python-wechat-itchat

- pip install itchat
- pip install jieba
- pip install pillow
- pip install wordcloud
- pip install echarts-python

